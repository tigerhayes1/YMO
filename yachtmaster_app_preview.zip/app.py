# Yachtmaster Offshore Interactive App
print('App loaded')