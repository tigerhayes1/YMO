Instructions:
- Run this app using Streamlit or deploy it via Replit.
- Built for iPad and browser use.
- Includes chart plotting, tidal tools, and exam questions.
